// hosein zarei 40223038
#include <stdio.h>
#include <stdlib.h>

struct time
{
    int min;
    int sec;
};

struct runner
{
    char firstName[20];
    char lastName[20];
    int ID;
    struct time *record;
    struct time runningTime;
};

int main()
{
    int n, i, j, counter = 0;
    printf("the number of runners: ");
    scanf("%d", &n);

    struct runner *runners = (struct runner *)malloc(n * sizeof(struct runner));

    for (i = 0; i < n; i++)
    {
        printf("the first name of runner %d: ", i + 1);
        scanf("%s", runners[i].firstName);
        printf("the last name of runner %d: ", i + 1);
        scanf("%s", runners[i].lastName);
        printf("the ID of runner %d: ", i + 1);
        scanf("%d", &runners[i].ID);

        runners[i].record = (struct time *)malloc(sizeof(struct time));

        printf("the record of runner %d: ", i + 1);
        scanf("%d %d", &runners[i].record->min, &runners[i].record->sec);

        printf("the running time of runner %d: ", i + 1);
        scanf("%d %d", &runners[i].runningTime.min, &runners[i].runningTime.sec);
    }

    int temp = 0;
    for (i = 1; i < n; i++)
    {
        if (runners[i].runningTime.min < runners[temp].runningTime.min || (runners[i].runningTime.min == runners[temp].runningTime.min &&
                                                                           runners[i].runningTime.sec < runners[temp].runningTime.sec))
        {
            temp = i;
        }
    }

    printf("The winner is: %s %s\n", runners[temp].firstName, runners[temp].lastName);
    if (runners[temp].runningTime.min < runners[temp].record->min || (runners[temp].runningTime.min == runners[temp].record->min &&
                                                                      runners[temp].runningTime.sec < runners[temp].record->sec))
    {
        printf("The runner breaks his record.\n");
    }
    else
    {
        printf("The runner does not break his record.\n");
    }

    for (i = 0; i < n; i++)
    {
        if (runners[temp].runningTime.min < runners[i].record->min ||
            (runners[temp].runningTime.min == runners[i].record->min &&
             runners[temp].runningTime.sec < runners[i].record->sec))
        {
            counter++;
        }
    }

    if (counter == n)
    {
        printf("The runner breaks all records.\n");
    }
    else
    {
        printf("The runner does not break all records.\n");
    }

    printf("First name\tLast Name\tID\tRecord\t\tRunningtime\n");
    for (j = 0; j < n; j++)
    {
        printf("%s\t\t%s\t\t%d\t%d:%d\t\t%d:%d\n", runners[j].firstName, runners[j].lastName, runners[j].ID,
               runners[j].record->min, runners[j].record->sec, runners[j].runningTime.min, runners[j].runningTime.sec);
    }
    free(runners);
    return 0;
}